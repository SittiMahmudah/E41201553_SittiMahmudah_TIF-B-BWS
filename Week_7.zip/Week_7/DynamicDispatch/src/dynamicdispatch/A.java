/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DynamicDispatch;

/**
 *
 * @author Sitti Mahmudah
 */
public class A {

    void callthis(){
        System.out.println("Inside Class A's Method");
    }
}